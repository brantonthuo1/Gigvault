#!/usr/bin/env bash
# Usage: ./scripts/push-to-github.sh https://github.com/YOUR-USER/gigvault.git
# 1) Create an EMPTY repo on github.com first (no README, no .gitignore).
# 2) Make sure you are logged in to git (e.g. `gh auth login` or a saved credential/SSH key).
set -euo pipefail
REMOTE="${1:-}"
if [ -z "$REMOTE" ]; then echo "Give the GitHub repo URL as the first argument."; exit 1; fi
[ -d .git ] || git init
git add -A
git commit -m "Initial commit: GIGVAULT site" || true
git branch -M main
git remote remove origin 2>/dev/null || true
git remote add origin "$REMOTE"
git push -u origin main
echo "Pushed. Now import the repo at https://vercel.com/new"
