# GIGVAULT // Digital Intelligence Archive
Next.js 14 (App Router) + TypeScript. No database, auth or payments.

## Run locally
    npm install
    npm run dev        # http://localhost:3000
    npm run build      # production build check

## Put it on GitHub
1. Create an empty repo on github.com (no README/.gitignore), e.g. `gigvault`.
2. From this folder:

       ./scripts/push-to-github.sh https://github.com/YOUR-USER/gigvault.git

   Or manually:

       git init && git add -A && git commit -m "Initial commit"
       git branch -M main
       git remote add origin https://github.com/YOUR-USER/gigvault.git
       git push -u origin main

   (Windows: run the manual commands in Git Bash or PowerShell.)

## Deploy on Vercel
1. Go to https://vercel.com/new and import the GitHub repo (framework: Next.js, auto-detected).
2. Add environment variables (see `.env.example`):
   - `NEXT_PUBLIC_WHATSAPP_URL` e.g. https://wa.me/254XXXXXXXXX
   - `NEXT_PUBLIC_LINKEDIN_URL`
   - `NEXT_PUBLIC_SITE_URL` your final domain
3. Deploy. Every push to `main` redeploys automatically; GitHub Actions also runs a build check.

## Edit content
Articles live in `lib/content.ts`; contact settings in `lib/site.ts`.
