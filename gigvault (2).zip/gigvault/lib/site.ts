export const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://gigvault.vercel.app";
export const TELEGRAM = "https://t.me/Gigvault01";
export const WHATSAPP = process.env.NEXT_PUBLIC_WHATSAPP_URL || "";
export const LINKEDIN = process.env.NEXT_PUBLIC_LINKEDIN_URL || "";

export type Cat = { slug: string; code: string; nav: string; title: string; desc: string; cta: string };
export const CATS: Cat[] = [
  { slug: "online-income", code: "01", nav: "MAKE MONEY ONLINE", title: "ONLINE INCOME",
    desc: "Investigate legitimate digital income models, freelance services, writing opportunities, remote work, and digital products.", cta: "OPEN DIRECTORY" },
  { slug: "ai-training", code: "02", nav: "AI TRAINING", title: "AI TRAINING & DATA WORK",
    desc: "Understand the world of AI evaluation, data annotation, LLM training, language tasks, coding review, and human feedback.", cta: "ACCESS AI ARCHIVE" },
  { slug: "laws-of-power", code: "03", nav: "LAWS OF POWER", title: "LAWS OF POWER",
    desc: "Study strategic thinking, discipline, reputation, influence, negotiation, social intelligence, and the psychology of power.", cta: "ENTER STRATEGY ARCHIVE" },
  { slug: "cybersecurity", code: "04", nav: "DARK WEB / CYBERSECURITY", title: "DARK WEB & CYBERSECURITY",
    desc: "Explore the surface web, deep web, dark web, anonymity technologies, digital privacy, and lawful cybersecurity education.", cta: "OPEN SECURITY ARCHIVE" },
];
