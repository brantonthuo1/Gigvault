"use client";
import { useEffect, useRef } from "react";

export default function MatrixRain() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const weak = window.innerWidth < 700 || (navigator.hardwareConcurrency || 8) <= 4;
    if (reduce || weak) { c.style.display = "none"; return; }
    const ctx = c.getContext("2d")!;
    const size = 16;
    let cols = 0, drops: number[] = [], raf = 0, last = 0;
    const resize = () => { c.width = window.innerWidth; c.height = window.innerHeight;
      cols = Math.floor(c.width / size); drops = Array.from({ length: cols }, () => Math.random() * -50); };
    resize();
    window.addEventListener("resize", resize);
    const chars = "01アイウエオカキクケコサシスセソ<>/{}[];=+*";
    const draw = (t: number) => {
      raf = requestAnimationFrame(draw);
      if (t - last < 70) return;
      last = t;
      ctx.fillStyle = "rgba(2,6,3,0.12)"; ctx.fillRect(0, 0, c.width, c.height);
      ctx.fillStyle = "#008F11"; ctx.font = size + "px monospace";
      for (let i = 0; i < cols; i++) {
        ctx.fillText(chars[Math.floor(Math.random() * chars.length)], i * size, drops[i] * size);
        if (drops[i] * size > c.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
      }
    };
    raf = requestAnimationFrame(draw);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);
  return <canvas ref={ref} className="rain" aria-hidden="true" />;
}
