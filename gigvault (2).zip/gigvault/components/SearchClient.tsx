"use client";
import Link from "next/link";
import { useMemo, useState } from "react";

type Item = { slug: string; category: string; catTitle: string; title: string; description: string; text: string };

export default function SearchClient({ items, cats }: { items: Item[]; cats: { slug: string; title: string }[] }) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const res = useMemo(() => {
    const t = q.trim().toLowerCase();
    return items.filter((i) => (cat === "all" || i.category === cat) && (!t || (i.title + " " + i.description + " " + i.text).toLowerCase().includes(t)));
  }, [q, cat, items]);
  return (
    <div>
      <label htmlFor="q" className="muted">&gt; QUERY ARCHIVE</label>
      <input id="q" className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="type to search..." autoComplete="off" />
      <div className="btns" role="group" aria-label="Category filter">
        <button className={"btn" + (cat === "all" ? " primary" : "")} onClick={() => setCat("all")}>[ ALL ]</button>
        {cats.map((c) => (
          <button key={c.slug} className={"btn" + (cat === c.slug ? " primary" : "")} onClick={() => setCat(c.slug)}>[ {c.title} ]</button>
        ))}
      </div>
      <p className="muted" aria-live="polite">{res.length} RESULT(S)</p>
      <div className="grid">
        {res.map((i) => (
          <article className="card" key={i.category + i.slug}>
            <p className="meta">{i.catTitle}</p>
            <h3>{i.title}</h3><p>{i.description}</p>
            <Link className="btn" href={`/${i.category}/${i.slug}`}>[ READ ARTICLE ]</Link>
          </article>
        ))}
      </div>
    </div>
  );
}
