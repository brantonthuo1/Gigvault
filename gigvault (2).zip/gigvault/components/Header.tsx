"use client";
import Link from "next/link";
import { useState } from "react";
import { CATS } from "@/lib/site";

export default function Header() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return (
    <header className="hdr">
      <div className="wrap hdr-in">
        <Link href="/" className="logo glitch" data-text="GIGVAULT" onClick={close}>GIGVAULT<span className="cur">_</span></Link>
        <button className="menu-btn" aria-expanded={open} aria-controls="nav" onClick={() => setOpen(!open)}>
          {open ? "[ CLOSE ]" : "[ MENU ]"}
        </button>
        <nav id="nav" className={open ? "nav open" : "nav"} aria-label="Primary">
          {CATS.map((c) => (<Link key={c.slug} href={"/" + c.slug} onClick={close}>[{c.code}] {c.nav}</Link>))}
          <Link href="/about" onClick={close}>[05] ABOUT</Link>
          <Link href="/search" onClick={close}>[?] SEARCH</Link>
        </nav>
      </div>
    </header>
  );
}
