import Link from "next/link";
import { Article } from "@/lib/content";
import { CATS } from "@/lib/site";

export default function ArticleCard({ a }: { a: Article }) {
  const cat = CATS.find((c) => c.slug === a.category)!;
  return (
    <article className="card">
      <p className="meta">{cat.title} // {a.minutes} MIN // REVIEWED {a.reviewed}</p>
      <h3>{a.title}</h3>
      <p>{a.description}</p>
      <Link className="btn" href={`/${a.category}/${a.slug}`}>[ READ ARTICLE ]</Link>
    </article>
  );
}
