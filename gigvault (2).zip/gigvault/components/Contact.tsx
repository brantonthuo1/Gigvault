import { TELEGRAM, WHATSAPP, LINKEDIN } from "@/lib/site";

export default function Contact() {
  return (
    <div className="panel">
      <p>Looking for deeper research, curated resources, or additional guidance on a topic in the archive? Contact the operator to ask what information is currently available.</p>
      <div className="btns">
        <a className="btn primary" href={TELEGRAM} target="_blank" rel="noopener noreferrer">[ SEND TELEGRAM MESSAGE ]</a>
        {WHATSAPP && <a className="btn" href={WHATSAPP} target="_blank" rel="noopener noreferrer">[ CONTACT VIA WHATSAPP ]</a>}
        {LINKEDIN && <a className="btn" href={LINKEDIN} target="_blank" rel="noopener noreferrer">[ OPEN LINKEDIN PROFILE ]</a>}
      </div>
      <p className="muted">Telegram: @Gigvault01</p>
    </div>
  );
}
