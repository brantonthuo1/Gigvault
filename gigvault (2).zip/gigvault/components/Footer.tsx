import Link from "next/link";
import { CATS } from "@/lib/site";

export default function Footer() {
  return (
    <footer className="ftr">
      <div className="wrap">
        <p className="g">GIGVAULT // DIGITAL INTELLIGENCE ARCHIVE</p>
        <p className="muted">INDEPENDENT RESEARCH. EDUCATIONAL CONTENT. DIGITAL DISCOVERY.</p>
        <nav className="flinks" aria-label="Footer">
          {CATS.map((c) => <Link key={c.slug} href={"/" + c.slug}>{c.nav}</Link>)}
          <Link href="/about">ABOUT</Link><Link href="/contact">CONTACT</Link>
          <Link href="/privacy">PRIVACY</Link><Link href="/disclaimer">DISCLAIMER</Link>
        </nav>
      </div>
    </footer>
  );
}
