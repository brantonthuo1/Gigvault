import type { MetadataRoute } from "next";
import { ARTICLES } from "@/lib/content";
import { CATS, SITE_URL } from "@/lib/site";
export default function sitemap(): MetadataRoute.Sitemap {
  const pages = ["", "/about", "/contact", "/privacy", "/disclaimer", "/search"].map((p) => ({ url: SITE_URL + p }));
  return [...pages,
    ...CATS.map((c) => ({ url: `${SITE_URL}/${c.slug}` })),
    ...ARTICLES.map((a) => ({ url: `${SITE_URL}/${a.category}/${a.slug}`, lastModified: a.reviewed }))];
}
