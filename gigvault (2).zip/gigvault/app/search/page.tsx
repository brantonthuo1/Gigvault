import type { Metadata } from "next";
import { ARTICLES } from "@/lib/content";
import { CATS } from "@/lib/site";
import SearchClient from "@/components/SearchClient";

export const metadata: Metadata = { title: "Search the Archive", description: "Search every GIGVAULT article." };

export default function SearchPage() {
  const items = ARTICLES.map((a) => ({
    slug: a.slug, category: a.category, catTitle: CATS.find((c) => c.slug === a.category)!.title,
    title: a.title, description: a.description, text: a.sections.map((s) => s.h + " " + s.p.join(" ")).join(" "),
  }));
  return (<><h1>// SEARCH</h1><SearchClient items={items} cats={CATS.map((c) => ({ slug: c.slug, title: c.title }))} /></>);
}
