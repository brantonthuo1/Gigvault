import type { Metadata } from "next";
import Contact from "@/components/Contact";
export const metadata: Metadata = { title: "About", description: "About GIGVAULT, an independent digital research archive." };
export default function Page() {
  return (<div className="article"><h1>// ABOUT GIGVAULT</h1>
    <p>GIGVAULT is an independent digital research archive. Its goal is simple: find the signal, ignore the noise.</p>
    <p>Articles are educational introductions to online income, AI training work, strategic self-development and cybersecurity. They are not financial, legal or career advice, and they do not guarantee any result.</p>
    <p>Each article shows a last-reviewed date. Facts that change, such as pay, eligibility and hiring status, are not published unless they can be sourced and dated.</p>
    <Contact /></div>);
}
