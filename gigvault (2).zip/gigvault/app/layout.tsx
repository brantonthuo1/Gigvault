import type { Metadata } from "next";
import { JetBrains_Mono } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import MatrixRain from "@/components/MatrixRain";
import { SITE_URL } from "@/lib/site";

const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--mono", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: "GIGVAULT // Digital Intelligence Archive", template: "%s | GIGVAULT" },
  description: "Independent educational research on online income, AI training work, strategic self-development and cybersecurity. Find the signal. Ignore the noise.",
  openGraph: { title: "GIGVAULT // Digital Intelligence Archive", description: "Find the signal. Ignore the noise.", type: "website", siteName: "GIGVAULT" },
  twitter: { card: "summary", title: "GIGVAULT // Digital Intelligence Archive" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={mono.variable}>
      <body>
        <MatrixRain />
        <div className="scan" aria-hidden="true" />
        <a href="#main" className="skip">Skip to content</a>
        <Header />
        <main id="main" className="wrap">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
