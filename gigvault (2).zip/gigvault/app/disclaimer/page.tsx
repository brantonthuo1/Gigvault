import type { Metadata } from "next";
export const metadata: Metadata = { title: "Disclaimer", description: "Educational-use disclaimer for GIGVAULT." };
export default function Page() {
  return (<div className="article"><h1>// DISCLAIMER</h1>
    <p>All content is for general education only. It is not financial, legal, career or security advice.</p>
    <p>Earnings online are not guaranteed and vary widely. Platform rules, pay and eligibility change; verify with official sources.</p>
    <p>Cybersecurity content is defensive and educational. Never access systems or data without authorization, and obey the laws that apply to you. Links to outside sites are provided for convenience and are not endorsements.</p></div>);
}
