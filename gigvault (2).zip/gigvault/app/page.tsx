import Link from "next/link";
import { CATS, TELEGRAM } from "@/lib/site";
import { ARTICLES } from "@/lib/content";
import ArticleCard from "@/components/ArticleCard";

const ICONS = ["$_", "{AI}", ">>>", "0xDF"];

export default function Home() {
  return (
    <>
      <section className="hero">
        <p className="g">GIGVAULT // DIGITAL INTELLIGENCE</p>
        <p className="muted">[ SYSTEM STATUS: ONLINE ] &nbsp; [ ARCHIVE: OPEN ] &nbsp; [ RESEARCH CATEGORIES: 04 ]</p>
        <h1>THE INTERNET IS FULL OF INFORMATION. KNOW WHERE TO LOOK.<span className="cur">_</span></h1>
        <p className="lead">Explore online income opportunities, AI training careers, strategic self-development, and the technologies behind the hidden layers of the internet.</p>
        <div className="btns">
          <a className="btn primary" href="#archive">[ EXPLORE THE ARCHIVE ]</a>
          <Link className="btn" href="/contact">[ CONTACT THE OPERATOR ]</Link>
        </div>
        <p className="muted">&gt; SELECT A RESEARCH CATEGORY</p>
      </section>

      <section id="archive" aria-labelledby="cats">
        <h2 id="cats">// RESEARCH CATEGORIES</h2>
        <div className="grid">
          {CATS.map((c, i) => (
            <article className="card cat" key={c.slug}>
              <div className="icon" aria-hidden="true">{ICONS[i]}</div>
              <p className="meta">{c.code} // {c.title}</p>
              <p>{c.desc}</p>
              <Link className="btn" href={"/" + c.slug}>{c.cta} →</Link>
            </article>
          ))}
        </div>
      </section>

      <section aria-labelledby="recent">
        <h2 id="recent">// RECENT INTELLIGENCE</h2>
        <div className="grid">{ARTICLES.slice(0, 6).map((a) => <ArticleCard key={a.slug} a={a} />)}</div>
        <p><Link className="btn" href="/search">[ SEARCH ALL ARTICLES ]</Link></p>
      </section>

      <section className="panel">
        <h2>// WANT TO GO DEEPER?</h2>
        <p>The public archive covers the fundamentals. For expanded research or guidance on a topic, message the operator and ask what is currently available.</p>
        <a className="btn primary" href={TELEGRAM} target="_blank" rel="noopener noreferrer">[ REQUEST MORE INFORMATION ]</a>
      </section>
    </>
  );
}
