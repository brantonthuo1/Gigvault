import type { Metadata } from "next";
import Contact from "@/components/Contact";
export const metadata: Metadata = { title: "Contact the Operator", description: "Reach GigVault on Telegram to ask about expanded research and guidance." };
export default function Page() {
  return (<><h1>// CONTACT THE OPERATOR</h1><Contact />
    <p className="muted">No account or sign-up is needed. Buttons open the external app directly. Availability of additional material varies by topic, so ask what is currently available.</p></>);
}
