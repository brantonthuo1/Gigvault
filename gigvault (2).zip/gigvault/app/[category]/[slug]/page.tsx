import { notFound } from "next/navigation";
import Link from "next/link";
import type { Metadata } from "next";
import { ARTICLES, find } from "@/lib/content";
import { CATS, TELEGRAM } from "@/lib/site";

export const dynamicParams = false;
export const generateStaticParams = () => ARTICLES.map((a) => ({ category: a.category, slug: a.slug }));

export function generateMetadata({ params }: { params: { category: string; slug: string } }): Metadata {
  const a = find(params.category, params.slug);
  if (!a) return {};
  return { title: a.title, description: a.description,
    openGraph: { title: a.title, description: a.description, type: "article", modifiedTime: a.reviewed } };
}

export default function ArticlePage({ params }: { params: { category: string; slug: string } }) {
  const a = find(params.category, params.slug);
  if (!a) notFound();
  const cat = CATS.find((c) => c.slug === a.category)!;
  return (
    <article className="article">
      <p className="meta"><Link href={"/" + cat.slug}>{cat.title}</Link> // {a.minutes} MIN READ // LAST REVIEWED {a.reviewed}</p>
      <h1>{a.title}</h1>
      <p className="lead">{a.description}</p>
      {a.sections.map((s) => (
        <section key={s.h}><h2>{s.h}</h2>{s.p.map((t, i) => <p key={i}>{t}</p>)}</section>
      ))}
      {a.links && (<section><h2>Sources and further reading</h2>
        <ul>{a.links.map((l) => <li key={l.url}><a href={l.url} target="_blank" rel="noopener noreferrer">{l.label}</a></li>)}</ul></section>)}
      <div className="panel">
        <h2>// WANT TO GO DEEPER?</h2>
        <p>This introduction covers the fundamentals. If you are looking for expanded research, curated resources, or more detailed guidance on this topic, contact GigVault through Telegram.</p>
        <a className="btn primary" href={TELEGRAM} target="_blank" rel="noopener noreferrer">[ REQUEST MORE INFORMATION ]</a>
      </div>
      <p className="muted">Educational content only. See the <Link href="/disclaimer">disclaimer</Link>.</p>
    </article>
  );
}
