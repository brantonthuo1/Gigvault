import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { CATS } from "@/lib/site";
import { byCat } from "@/lib/content";
import ArticleCard from "@/components/ArticleCard";
import Contact from "@/components/Contact";

export const dynamicParams = false;
export const generateStaticParams = () => CATS.map((c) => ({ category: c.slug }));

export function generateMetadata({ params }: { params: { category: string } }): Metadata {
  const c = CATS.find((x) => x.slug === params.category);
  return c ? { title: c.title, description: c.desc } : {};
}

export default function CategoryPage({ params }: { params: { category: string } }) {
  const c = CATS.find((x) => x.slug === params.category);
  if (!c) notFound();
  return (
    <>
      <section className="hero">
        <p className="g">ACCESSING KNOWLEDGE ARCHIVE... [{c.code}]</p>
        <h1>{c.title}</h1>
        <p className="lead">{c.desc}</p>
      </section>
      <div className="grid">{byCat(c.slug).map((a) => <ArticleCard key={a.slug} a={a} />)}</div>
      <h2>// WANT TO GO DEEPER?</h2>
      <Contact />
    </>
  );
}
