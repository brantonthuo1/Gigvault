import type { Metadata } from "next";
export const metadata: Metadata = { title: "Privacy", description: "How GIGVAULT handles visitor data." };
export default function Page() {
  return (<div className="article"><h1>// PRIVACY</h1>
    <p>This website has no accounts, forms, newsletters or payment features, and it does not ask you for personal information.</p>
    <p>If you click a contact button you leave this site and are subject to the privacy policy of that platform (Telegram, WhatsApp or LinkedIn). Anything you send there is shared with the site operator.</p>
    <p>The site is hosted on Vercel, which may process standard technical logs such as IP address and request data. Add any analytics or cookie notices here if you enable them later.</p></div>);
}
